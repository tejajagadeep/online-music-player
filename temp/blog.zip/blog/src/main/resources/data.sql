INSERT INTO todo (id,description, title) VALUES
(1,'Description 1', 'Title 1'),
(2,'Description 2', 'Title 2'),
(3,'Description 3', 'Title 3');
-- Add more rows as needed
